//Carmen Mendoza
//CSD420 
//Write a test program that stores 50,000 integers in LinkedList and test the time to traverse the list using an iterator vs. using the get(index) method. 

import java.util.*;

public class LinkedListTraversalTest {
    public static void main(String[] args) {
        System.out.println("Testing with 50,000 elements:");
        runTest(50000);
        System.out.println("Testing with 500,000 elements:");
        runTest(500000);
    }

    public static void runTest(int size) {
        LinkedList<Integer> list = new LinkedList<>();
        for (int i = 0; i < size; i++) {
            list.add(i);
        }

        // Test using Iterator
        long start = System.nanoTime();
        Iterator<Integer> it = list.iterator();
        while (it.hasNext()) {
            it.next();
        }
        long end = System.nanoTime();
        System.out.println("Iterator time: " + (end - start) / 1_000_000.0 + " ms");

        // Test using get(index)
        start = System.nanoTime();
        for (int i = 0; i < list.size(); i++) {
            list.get(i);
        }
        end = System.nanoTime();
        System.out.println("get(index) time: " + (end - start) / 1_000_000.0 + " ms");
    }
}
