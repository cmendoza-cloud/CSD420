//Carmen Mendoza
//CSD420 
//Module 2

//Write a program that stores
//An array of five random integers
//An array of five random double values 

import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class WriteToFile {
    public static void main(String[] args) {
        String fileName = "Mendoza_datafile.dat"; // Output file name
        Random random = new Random();

        try {
            FileWriter fileWriter = new FileWriter(fileName, true); // Open file in append mode
            PrintWriter writer = new PrintWriter(fileWriter);

            // Generate and write 5 random integers
            writer.print("Integers: ");
            for (int i = 0; i < 5; i++) {
                int num = random.nextInt(100); // Random number between 0-99
                writer.print(num + " ");
            }
            writer.println(); // New line

            // Generate and write 5 random doubles
            writer.print("Doubles: ");
            for (int i = 0; i < 5; i++) {
                double num = random.nextDouble() * 100; // Random double between 0-100
                writer.printf("%.2f ", num); // Formatting to 2 decimal places
            }
            writer.println();
            writer.println("-----");

            // Close the writer
            writer.close();
            System.out.println("Data successfully written to " + fileName);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }
}
