//Carmen Mendoza
//
//CSD 420 
//Write a test program that contains a static method that returns a new ArrayList

import java.util.*;

public class RemoveDuplicates {
    public static void main(final String[] args) {
        // Create an ArrayList to store numbers
        final ArrayList<Integer> numbers = new ArrayList<>();
        final Random rand = new Random();
        
        // Fill the ArrayList with 50 random numbers from 1 to 20
        for (int i = 0; i < 50; i++) {
            numbers.add(rand.nextInt(20) + 1);
        }
        
        // Display the original list
        System.out.println("Original list: " + numbers);
        
        // Call the method to remove duplicates
        final ArrayList<Integer> uniqueNumbers = removeDuplicates(numbers);
        
        // Display the list without duplicates
        System.out.println("List without duplicates: " + uniqueNumbers);
    }
    
    public static <E> ArrayList<E> removeDuplicates(final ArrayList<E> list) {
        // Use a LinkedHashSet to remove duplicates and keep order
        return new ArrayList<>(new LinkedHashSet<>(list));
    }
}